package MODELO.DAO.InventarioPieza;

public class InventarioPiezaDAO {
}
