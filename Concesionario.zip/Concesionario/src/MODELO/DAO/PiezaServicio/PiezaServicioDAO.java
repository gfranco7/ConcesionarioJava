package MODELO.DAO.PiezaServicio;

public class PiezaServicioDAO {
}
