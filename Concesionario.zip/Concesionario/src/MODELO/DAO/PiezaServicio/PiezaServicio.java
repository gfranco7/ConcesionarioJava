package MODELO.DAO.PiezaServicio;

public class PiezaServicio {
}
