package MODELO.DAO.Empleado;

public class Empleado {
    private int cedula;
    private String nombre;
    private String apellido;
    private String fecha_nacimiento;
    private String direccion;
    private String telefono;
    private String tipo;
}
