package MODELO.DAO.Empleado;

public class EmpleadoDAO {
}
