package MODELO.DAO.InventarioVehiculo;

public class InventarioVehiculo {
    private int id;
    private int cantidad;
    private int lote;
    private String tipo;


    public InventarioVehiculo(int id, int cantidad, int lote, String tipo) {
        this.id = id;
        this.cantidad = cantidad;
        this.lote = lote;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getLote() {
        return lote;
    }

    public void setLote(int lote) {
        this.lote = lote;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "InventarioVehiculo{" +
                "id=" + id +
                ", cantidad=" + cantidad +
                ", lote=" + lote +
                ", tipo='" + tipo + '\'' +
                '}';
    }
}
