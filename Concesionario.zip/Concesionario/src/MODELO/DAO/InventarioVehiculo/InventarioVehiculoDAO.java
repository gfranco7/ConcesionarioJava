package MODELO.DAO.InventarioVehiculo;

import MODELO.CONEXION.Conexion;
import MODELO.DAO.IDAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class InventarioVehiculoDAO implements IDAO {

    private Conexion conexionInst = Conexion.getInstance();

    @Override
    public List<Object> listar() {
        return null;
    }

    @Override
    public boolean buscar(Object object) {
        return false;
    }

    @Override
    public boolean agregar(Object object) {
        return false;
    }

    @Override
    public boolean modificar(Object object) {
        return false;
    }


    public List<String> listarInventarioV() {
        List<String> inventarioVeh = new ArrayList<>();

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT lote, tipo from inventariovehiculo";

        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                inventarioVeh.add(rs.getString("lote"));
                inventarioVeh.add(rs.getString("tipo"));
            }

        } catch (Exception e) {
            System.out.println("Hubo un error al listar el inventario de vehiculos: " + e.getMessage());
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar conexión: " + e.getMessage());
            }
        }
        return inventarioVeh;
    }


    public static void main(String[] args) {
        InventarioVehiculoDAO InvDAO = new InventarioVehiculoDAO();
        List<String> datosCl = new ArrayList<>();
        datosCl=InvDAO.listarInventarioV();
        for (int i = 0; i < datosCl.size(); i++) {
            System.out.println(datosCl.get(i));
        }
    }

}

