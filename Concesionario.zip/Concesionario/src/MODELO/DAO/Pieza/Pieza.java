package MODELO.DAO.Pieza;

public class Pieza {
}
