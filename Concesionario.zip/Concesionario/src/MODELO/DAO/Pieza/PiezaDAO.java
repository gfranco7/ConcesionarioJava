package MODELO.DAO.Pieza;

public class PiezaDAO {
}
