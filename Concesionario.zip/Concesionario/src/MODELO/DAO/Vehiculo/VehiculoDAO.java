package MODELO.DAO.Vehiculo;

import MODELO.CONEXION.Conexion;
import MODELO.DAO.IDAO;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class VehiculoDAO implements IDAO {

    private Conexion conexionInst = Conexion.getInstance();

    @Override
    public List<Object> listar() {
        return null;
    }

    @Override
    public boolean buscar(Object object) {
        return false;
    }

    @Override
    public boolean agregar(Object object) {
        return false;
    }

    @Override
    public boolean modificar(Object object) {
        return false;
    }


    public List<String> ListarVehiculo() {
        List<String> Vehiculos = new ArrayList<>();

        PreparedStatement ps;
        ResultSet rs;

        Connection con = conexionInst.getConexion();

        var sql = "SELECT marca, modelo, precio from vehiculo";

        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Vehiculos.add(rs.getString("marca"));
                Vehiculos.add(rs.getString("modelo"));
                Vehiculos.add(rs.getString("precio"));

            }

        } catch (Exception e) {
            System.out.println("Hubo un error al listar vehiculos: " + e.getMessage());
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.out.println("Error al cerrar conexión: " + e.getMessage());
            }
        }
        return Vehiculos;
    }


    public static void main(String[] args) {
        VehiculoDAO VehiculoDAO = new VehiculoDAO();
        List<String> datosCl = new ArrayList<>();
        datosCl=VehiculoDAO.ListarVehiculo();
        for (int i = 0; i < datosCl.size(); i++) {
            System.out.println(datosCl.get(i));
        }
    }

}

