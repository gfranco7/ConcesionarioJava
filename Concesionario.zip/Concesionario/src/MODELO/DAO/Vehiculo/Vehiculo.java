package MODELO.DAO.Vehiculo;

public class Vehiculo {
    private int id;
    private String placa;
    private String marca;
    private String modelo;
    private String estado;
    private int precio;
    private String fecha_fabrica;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getFecha_fabrica() {
        return fecha_fabrica;
    }

    public void setFecha_fabrica(String fecha_fabrica) {
        this.fecha_fabrica = fecha_fabrica;
    }

    @Override
    public String toString() {
        return "Vehiculo{" +
                "id=" + id +
                ", placa='" + placa + '\'' +
                ", marca='" + marca + '\'' +
                ", modelo='" + modelo + '\'' +
                ", estado='" + estado + '\'' +
                ", precio=" + precio +
                ", fecha_fabrica='" + fecha_fabrica + '\'' +
                '}';
    }
}
