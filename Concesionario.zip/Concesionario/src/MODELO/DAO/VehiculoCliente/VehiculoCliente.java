package MODELO.DAO.VehiculoCliente;

public class VehiculoCliente {
}
