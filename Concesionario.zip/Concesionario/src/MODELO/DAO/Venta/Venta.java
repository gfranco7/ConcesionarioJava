package MODELO.DAO.Venta;

public class Venta {
}
