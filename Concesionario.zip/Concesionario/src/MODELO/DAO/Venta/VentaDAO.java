package MODELO.DAO.Venta;

public class VentaDAO {
}
