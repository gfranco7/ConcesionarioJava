package MODELO.DAO.Proveedor;

public class Proveedor {
}
