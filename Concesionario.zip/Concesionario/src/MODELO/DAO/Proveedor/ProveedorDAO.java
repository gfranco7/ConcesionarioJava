package MODELO.DAO.Proveedor;

public class ProveedorDAO {
}
