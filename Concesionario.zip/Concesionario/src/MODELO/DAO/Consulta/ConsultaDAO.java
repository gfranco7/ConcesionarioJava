package MODELO.DAO.Consulta;

public class ConsultaDAO {
}
