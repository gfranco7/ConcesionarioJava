package MODELO.DAO.Consulta;

public class Consulta {
}
