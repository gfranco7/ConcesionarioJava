package MODELO.DAO.Servicio;

public class Servicio {
}
